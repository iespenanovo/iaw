

<?php 



	$clave="abc123.";

	$claveCodificada=password_hash($clave, PASSWORD_DEFAULT);



	echo "<br>Clave : $clave";

	echo "<br>Clave Codificada: $claveCodificada";

	echo "<br>Clave MD5: ".md5($clave);





 ?>