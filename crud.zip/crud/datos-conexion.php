<?php 
$servidor="localhost";
$usuario="root";
$clave="";
$baseDatos="crud";
?>